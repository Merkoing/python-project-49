### Hexlet tests and linter status:
[![Actions Status](https://github.com/Merkoing/python-project-49/workflows/hexlet-check/badge.svg)](https://github.com/Merkoing/python-project-49/actions)

<a href="https://codeclimate.com/github/Merkoing/python-project-49/maintainability"><img src="https://api.codeclimate.com/v1/badges/f0a6d4509ade1ee00dd7/maintainability" /></a>
